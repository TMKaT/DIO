# Processamento básico de imagens

O Processamento básico de imagens deste pacote permite:
	
- Módulo "processamento":
  - Correspondência de histograma;
  - Similaridade estrutural;
  - Redimensionar imagem;
	
- Módulo "utilidades":
  - Ler imagem;
  - Salvar imagem;
  - Plotar imagem;
  - Resultado do gráfico;
  - Plotar histograma;

## Instalação


```Instalação de dependências
!pip install -r requirements.txt
```

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/processamento_basico_de_imagens) para processamento_basico_de_imagens

```bash
!pip install processamento_basico_de_imagens
```

## Exemplo de uso

```python
from processamento_basico_de_imagens.processing import combinacao
combinacao.diferencas_imagens(img1, img2)
```

## Author
Joadir Damasceno Junior

## License
[MIT](https://choosealicense.com/licenses/mit/)